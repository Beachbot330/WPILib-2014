/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008-2012. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package edu.wpi.first.wpilibj.image;

import com.sun.cldc.jna.Structure;

/**
 * This is a dummy class which needs to be filled in.
 * @author dtjones
 */
public class RegionOfInterest extends Structure{

    public void read() {
    }

    public void write() {
    }

    public int size() {
        return 0;
    }

}
